
var Name : string = "Marvellous Infosystems"

console.log(Name)