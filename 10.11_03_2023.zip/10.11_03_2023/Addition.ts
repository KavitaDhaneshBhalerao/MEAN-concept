
var No1 : number = 10
var No2 : number = 11

var Ans : number = 0

Ans = No1 + No2

console.log("Addition is : "+Ans)