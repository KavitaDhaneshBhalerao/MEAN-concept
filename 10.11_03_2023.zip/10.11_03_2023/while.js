var Week = [11, 21, 51, 101, 111];
var Cnt = 0;
do {
    console.log(Week[Cnt]);
    Cnt++;
} while (Cnt < Week.length);
