
var No1 : number = 11

var No2 = 11

var No3

var No4 : number

var No5 : number = 90.99


