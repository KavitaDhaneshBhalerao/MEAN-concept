function Addition(No1, No2) {
    var Ans = 0;
    Ans = No1 + No2;
    return Ans;
}
var Ret = 0;
Ret = Addition(10, 11);
console.log("Addition is : " + Ret);
