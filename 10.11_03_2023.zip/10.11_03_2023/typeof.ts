var No  = 11

var Str  = "Marvelous"

console.log(typeof No)
console.log(typeof Str)
