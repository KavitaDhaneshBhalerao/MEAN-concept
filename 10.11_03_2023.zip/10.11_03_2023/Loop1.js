var Cnt = 0;
while (Cnt <= 5) {
    console.log(Cnt);
    Cnt++;
}
