var Week : number[] = [11,21,51,101,111]

var Cnt = 0;

while(Cnt <= 5)
{
    console.log(Cnt);
    Cnt++;
}