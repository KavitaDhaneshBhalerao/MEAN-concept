console.log("Test code");

var No1 : number = 11;

console.log("Value of No1 "+No1);

var Technology : string = "Angular";

var KYC : boolean = false;

var Gender : boolean = true;

console.log(typeof KYC);
console.log(typeof Technology);
console.log(typeof No1);

