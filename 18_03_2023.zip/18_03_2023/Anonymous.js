// Anonymous Function
var Ret = function (A, B) {
    return A + B;
};
console.log(Ret(10, 11));
