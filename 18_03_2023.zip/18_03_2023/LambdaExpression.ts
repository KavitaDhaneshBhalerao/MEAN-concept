// Lambda expression

var Ret = (A: number, B : number) => A+B;

console.log(Ret(10,11));