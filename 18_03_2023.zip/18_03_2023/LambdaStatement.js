// Lambda statement

var Addition = function (A, B) {
    console.log("Inside Lambda statement");
    return A + B;
};
console.log(Addition(10, 11));
