console.log("Test code");
var No1 = 11;
console.log("Value of No1 " + No1);
var Technology = "Angular";
var KYC = false;
var Gender = true;
console.log(typeof KYC);
console.log(typeof Technology);
console.log(typeof No1);
