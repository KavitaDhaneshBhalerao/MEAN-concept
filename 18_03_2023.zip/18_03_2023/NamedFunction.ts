// Named function

function Addition(A : number, B : number) : number
{
    return A+B;
}

var Ret : number = Addition(10,20);

console.log(Ret);