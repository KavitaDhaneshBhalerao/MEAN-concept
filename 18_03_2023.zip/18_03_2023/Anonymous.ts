
// Anonymous Function

var Addition = function(A : number, B : number) : number
{
    return A+B;
}

console.log(Addition(10,11));