// ->   =>
// Lambda statement

var Addition = (A : number, B : number) => {
    console.log("Inside Lambda statement");
    return A+B;
}

console.log(Addition(10,11));
